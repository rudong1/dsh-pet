const {chromium}=require('/workspace/.dsh-pet-env/node_modules/playwright-core');
const assert=require('node:assert/strict');
(async()=>{
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox'],headless:true});
try{
const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.clock.install();await page.goto('http://127.0.0.1:8766');
await page.waitForFunction(()=>[...document.images].length===8&&[...document.images].every(i=>i.complete&&i.naturalWidth>0));
assert.match(await page.locator('#caption').innerText(),/上班/);
await page.locator('#restart').click();await page.clock.runFor(40000);
assert.equal(await page.locator('#scene').innerText(),'9 / 9');
assert.match(await page.locator('#caption').innerText(),/并肩战斗/);
assert.equal(await page.locator('#play').innerText(),'重播');
await page.locator('#restart').click();await page.clock.runFor(3700);await page.locator('#play').click();
const before=await page.locator('#scene').innerText();await page.clock.runFor(10000);assert.equal(await page.locator('#scene').innerText(),before);
await page.locator('#next').click();assert.equal(await page.locator('#scene').innerText(),'3 / 9');
await page.locator('#background').selectOption('dark');assert.match(await page.locator('#stage').getAttribute('class'),/dark/);
await page.locator('#background').selectOption('light');assert.match(await page.locator('#stage').getAttribute('class'),/light/);
await page.locator('#timeline').fill('7');assert.match(await page.locator('#caption').innerText(),/收下/);
assert.deepEqual(errors,[]);console.log('PASS 8 decoded images; 9 scenes play to ending; pause; restart; next; timeline; background controls; no browser errors');
}finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
